﻿using RoadelixMission.Fundamentals;
using RoadelixMission.Proficiencies;

/*int BTD1 = Basics.BinaryToDecimal("1");      // BTD1 == 1
int BTD2 = Basics.BinaryToDecimal("1010");   // BTD2 == 10
int BTD3 = Basics.BinaryToDecimal("");       // BTD3 == 0
int BTD4 = Basics.BinaryToDecimal("0");      // BTD4 == 0



Console.WriteLine(BTD1);
Console.WriteLine(BTD2);
Console.WriteLine(BTD3);
Console.WriteLine(BTD4);


string DTB1 = Basics.DecimalToBinary(42);      // DTB1 == "101010"
string DTB2 = Basics.DecimalToBinary(2);       // DTB2 == "10"
string DTB3 = Basics.DecimalToBinary(0);       // DTB3 == "0"
string DTB4 = Basics.DecimalToBinary(146872);  // DTB4 == "100011110110111000"


Console.WriteLine(DTB1);
Console.WriteLine(DTB2);
Console.WriteLine(DTB3);
Console.WriteLine(DTB4);


bool CFF1 = Basics.ConvertFromFile("convert_tests.txt", "convert_tests_out.txt");   // CFF1 == true
bool CFF2 = Basics.ConvertFromFile("unknown_file.txt", "convert_tests_out.txt");    // CFF2 == false
Console.WriteLine(CFF1);
Console.WriteLine(CFF2);

int path1 = Basics.CountPath(1,1);    // path1 == 1
int path2 = Basics.CountPath(1,5);    // path2 == 1
int path3 = Basics.CountPath(3,3);    // path3 == 6
int path4 = Basics.CountPath(8,4);    // path4 == 120

Console.WriteLine(path1);
Console.WriteLine(path2);
Console.WriteLine(path3);
Console.WriteLine(path4);*/


/*bool parenthesis1 = DebugMe.GoodParenthesis("(abc)");     // parenthesis1 == true
bool parenthesis2 = DebugMe.GoodParenthesis(")(abc)(");   // parenthesis2 == false
bool parenthesis3 = DebugMe.GoodParenthesis("(abc))");    // parenthesis3 == false
bool parenthesis4 = DebugMe.GoodParenthesis("(abc)()");   // parenthesis4 == true
bool parenthesis5 = DebugMe.GoodParenthesis("");          // parenthesis5 == true
Console.WriteLine(parenthesis1);
Console.WriteLine(parenthesis2);
Console.WriteLine(parenthesis3);
Console.WriteLine(parenthesis4);
Console.WriteLine(parenthesis5);

int cata0 = DebugMe.Catalan(0);   // cata0 == 1
int cata1 = DebugMe.Catalan(1);   // cata1 == 1
int cata2 = DebugMe.Catalan(2);   // cata2 == 2
int cata3 = DebugMe.Catalan(3);   // cata3 == 5
int cata4 = DebugMe.Catalan(4);   // cata4 == 14
int cata5 = DebugMe.Catalan(5);   // cata5 == 42
int cata6 = DebugMe.Catalan(6);   // cata6 == 132
int cata7 = DebugMe.Catalan(7);   // cata7 == 429
Console.WriteLine(cata0);
Console.WriteLine(cata1);
Console.WriteLine(cata2);
Console.WriteLine(cata3);
Console.WriteLine(cata4);
Console.WriteLine(cata5);
Console.WriteLine(cata6);
Console.WriteLine(cata7);

(int, int) sum1 = DebugMe.CalculateSums(1, 5);     // sum1 == (6,9)
(int, int) sum2 = DebugMe.CalculateSums(2, 7);     // sum2 == (12,15)
(int, int) sum3 = DebugMe.CalculateSums(1, 10);    // sum3 == (30,25)
(int, int) sum4 = DebugMe.CalculateSums(0, 2);     // sum4 == (2,1)
(int, int) sum5 = DebugMe.CalculateSums(3, 3);     // sum5 == (0,3)

Console.WriteLine(sum1);
Console.WriteLine(sum2);
Console.WriteLine(sum3);
Console.WriteLine(sum4);

string pyra0 = DebugMe.Pyramid(0);   // pyra0 == ""
string pyra1 = DebugMe.Pyramid(1);   // pyra1 == "/_\"
string pyra2 = DebugMe.Pyramid(2);   // pyra2 == "  /_\\n/_\_/_\"
string pyra3 = DebugMe.Pyramid(3);   // pyra3 == "    /_\\n  /_\_/_\\n/_\_/_\_/_\"
string pyra4 = DebugMe.Pyramid(4);   // pyra4 == "      /_\\n    /_\_/_\\n  /_\_/_\_/_\\n/_\_/_\_/_\_/_\"

Console.WriteLine($"size 0:\n{pyra0}\n");
Console.WriteLine($"size 1:\n{pyra1}\n");
Console.WriteLine($"size 2:\n{pyra2}\n");
Console.WriteLine($"size 3:\n{pyra3}\n");
Console.WriteLine($"size 4:\n{pyra4}\n"); */


/*ng = ReadAVillage.GetVillageName("niort.txt");       // GVN1 == "Niort"
string GVN2 = ReadAVillage.GetVillageName("no_exists.txt");   // GVN2 == "Unknown"
Console.WriteLine(GVN1);
Console.WriteLine(GVN2);

(int GVC11, int GVC12) = ReadAVillage.GetVillageCoords("niort.txt");       // GVC11 == 3 && GVC12 == 3
(int GVC21, int GVC22) = ReadAVillage.GetVillageCoords("no_exists.txt");   // GVC21 == -1 && GVC22 == -1
(int GVC31, int GVC32) = ReadAVillage.GetVillageCoords("brest.txt");       // GVC31 == -1 && GVC32 == -1
(int GVC41, int GVC42) = ReadAVillage.GetVillageCoords("aiffres.txt");     // GVC41 == -1 && GVC42 == -1
Console.WriteLine(GVC11);
Console.WriteLine(GVC12);
Console.WriteLine(GVC21);
Console.WriteLine(GVC22);
Console.WriteLine(GVC31);
Console.WriteLine(GVC32);
Console.WriteLine(GVC41);
Console.WriteLine(GVC42);
    
    
(string GVR11, string GVR12, string GVR13, string GVR14) = ReadAVillage.GetVillageResources("niort.txt");       // GVR11 == GVR12 == GVR13 == GVR14 == "1000"
(string GVR21, string GVR22, string GVR23, string GVR24) = ReadAVillage.GetVillageResources("no_exists.txt");   // GVR21 == GVR22 == GVR23 == GVR24 == "0"
(string GVR31, string GVR32, string GVR33, string GVR34) = ReadAVillage.GetVillageResources("aiffres.txt");     // GVR31 == GVR32 == GVR33 == GVR34 == "0"
Console.WriteLine(GVR11);
Console.WriteLine(GVR12);
Console.WriteLine(GVR13);
Console.WriteLine(GVR14);
Console.WriteLine(GVR31);
Console.WriteLine(GVR32);
Console.WriteLine(GVR33);
Console.WriteLine(GVR34);
Console.WriteLine(GVR21);
Console.WriteLine(GVR22);
Console.WriteLine(GVR23);
Console.WriteLine(GVR24);

int CB7TD1 = ReadAVillage.ConvertBase7ToDecimal("60");       // CB7TD1 == 42
int CB7TD2 = ReadAVillage.ConvertBase7ToDecimal("606");      // CB7TD2 == 300
int CB7TD3 = ReadAVillage.ConvertBase7ToDecimal("123456");   // CB7TD3 == 22875
int CB7TD4 = ReadAVillage.ConvertBase7ToDecimal("35000");    // CB7TD4 == 8918

Console.WriteLine(CB7TD1);
Console.WriteLine(CB7TD2);
Console.WriteLine(CB7TD3);
Console.WriteLine(CB7TD4); */

/* 
int ED1 = Distances.EuclideanDistance(0, 0, 0, 0);      // ED1 == 0
int ED2 = Distances.EuclideanDistance(1, 0, 0, 0);      // ED2 == 1
int ED3 = Distances.EuclideanDistance(-1, -1, 0, 0);    // ED3 == 2
int ED4 = Distances.EuclideanDistance(0, 0, -1, -1);    // ED4 == 2
int ED5 = Distances.EuclideanDistance(0, 42, 42, 0);    // ED5 == 60
int ED6 = Distances.EuclideanDistance(5, 19, 45, 23);   // ED6 == 41
Console.WriteLine(ED1); 
Console.WriteLine(ED2); 
Console.WriteLine(ED3); 
Console.WriteLine(ED4); 
Console.WriteLine(ED5); 
Console.WriteLine(ED6); 

int MD1 = Distances.ManhattanDistance(0, 0, 0, 0);      // MD1 == 0
int MD2 = Distances.ManhattanDistance(1, 0, 0, 0);      // MD2 == 1
int MD3 = Distances.ManhattanDistance(-1, -1, 0, 0);    // MD3 == 2
int MD4 = Distances.ManhattanDistance(0, 0, -1, -1);    // MD4 == 2
int MD5 = Distances.ManhattanDistance(0, 42, 42, 0);    // MD5 == 84
int MD6 = Distances.ManhattanDistance(5, 19, 45, 23);   // MD6 == 44
Console.WriteLine(MD1); 
Console.WriteLine(MD2); 
Console.WriteLine(MD3); 
Console.WriteLine(MD4); 
Console.WriteLine(MD5); 
Console.WriteLine(MD6);



int ED21 = Distances.EuclideanDistance2(0, 0, 0, 0, 1.3);       // ED21 == 0
int ED22 = Distances.EuclideanDistance2(1, 0, 0, 0, 1.3);       // ED22 == 2
int ED23 = Distances.EuclideanDistance2(-1, -1, 0, 0, 1.3);     // ED23 == 2
int ED24 = Distances.EuclideanDistance2(0, 0, -1, -1, 2.3);     // ED24 == 4
int ED25 = Distances.EuclideanDistance2(0, 42, 42, 0, 1.2);     // ED25 == 72
int ED26 = Distances.EuclideanDistance2(5, 19, 45, 23, 1.92);   // ED26 == 78
Console.WriteLine(ED21); 
Console.WriteLine(ED22); 
Console.WriteLine(ED23); 
Console.WriteLine(ED24); 
Console.WriteLine(ED25); 
Console.WriteLine(ED26); */


/*bool RC1 = Resources.ResourcesCheck(10, 1000, 1000, 1000, 1000);   // RC1 == true
bool RC2 = Resources.ResourcesCheck(10, 15, 1000, 1000, 1000);     // RC2 == false
bool RC3 = Resources.ResourcesCheck(10, 1000, 99, 1000, 1000);     // RC3 == false
bool RC4 = Resources.ResourcesCheck(10, 1000, 1000, 999, 1000);    // RC4 == false
bool RC5 = Resources.ResourcesCheck(10, 1000, 1000, 1000, 219);    // RC5 == false
 

Console.WriteLine(RC1); 
Console.WriteLine(RC2); 
Console.WriteLine(RC3); 
Console.WriteLine(RC4); 
Console.WriteLine(RC5); */

/*int BS1 = Road.BuildSection("niort.txt", "rennes.txt", 1.3);     // BS1 == 10
int BS2 = Road.BuildSection("rennes.txt", "niort.txt", 1.3);     // BS2 == -1
int BS3 = Road.BuildSection("aiffres.txt", "rennes.txt", 1.3);   // BS3 == -1
int BS4 = Road.BuildSection("niort.txt", "brest.txt", 1.3);      // BS4 == -1
int BS5 = Road.BuildSection("no_exists.txt", "niort.txt", 1.3);  // BS5 == -1
Console.WriteLine(BS1);
Console.WriteLine(BS2);
Console.WriteLine(BS3); 
Console.WriteLine(BS4);
Console.WriteLine(BS5);*/

/*string GP1 = Papyrus.GetParameter("Gold:50");    // GP1 == "Gold"
string GP2 = Papyrus.GetParameter("Guards:3");   // GP2 == "Guards"
Console.WriteLine(GP2);
Console.WriteLine(GP1);*/


/*string GD1 = Papyrus.GetData("Gold:50");    // GD1 == "50"
string GD2 = Papyrus.GetData("Guards:3");   // GD2 == "3"
string GD3 = Papyrus.GetData(":1");         // GD3 == "1"
Console.WriteLine(GD1);
Console.WriteLine(GD2);
Console.WriteLine(GD3);*/

/*int RS1 = Attack.RegimentSize(0);    // RS1 == 0
int RS2 = Attack.RegimentSize(1);    // RS2 == 1
int RS3 = Attack.RegimentSize(3);    // RS3 == 6
int RS4 = Attack.RegimentSize(5);    // RS4 == 15

Console.WriteLine(RS1);
Console.WriteLine(RS2);
Console.WriteLine(RS3);
Console.WriteLine(RS4);*/

