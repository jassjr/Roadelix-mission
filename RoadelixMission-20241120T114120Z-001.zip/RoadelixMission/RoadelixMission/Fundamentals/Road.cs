namespace RoadelixMission.Fundamentals;


public class Road
{
    public static int BuildSection(string startPath, string endPath, double distCoef)
    {
        try
        { string a = ReadAVillage.GetVillageName(startPath); string b = ReadAVillage.GetVillageName(endPath); // ethe string a teh b kita 

            if (a == "Unknown" || b == "Unknown") return -1; // ethe main if kita 
            
            (int mv, int cv) = ReadAVillage.GetVillageCoords(startPath); (int ma, int mb) = ReadAVillage.GetVillageCoords(endPath);
            // ethe main lv kita 


            if (mv == -1 || cv == -1 || ma == -1 || mb == -1) return -1; // ehte if kita 

            int manpower, wood, stone, iron; // ethe int kita 
            using (StreamReader ls = new StreamReader(startPath))
            { ls.ReadLine(); ls.ReadLine(); ls.ReadLine(); // readerline kita ls karke 
            }
            int distance = Distances.EuclideanDistance2(mv, cv, ma, mb, distCoef); // ethe distance kita 
        }
        catch { return -1; } // ethe rt -1 kita 


        return -1; // ethe rt -1 kita 
    }

   
    public static bool BuildRoad(string inputFile, string outputFile, double distCoef) { }

}