namespace RoadelixMission.Fundamentals;

public class Basics
{
   public static int BinaryToDecimal(string data)
   {
       foreach (char j in data) // ethe main foreach kita 
       {
           if (j != '0' && j != '1') // ethe main if kita
               throw new ArgumentException("Unknown character");
       }
       int l = 0; // ethe main int kita 
       int s = 1; // int kita 
       for (int a = data.Length - 1; a >= 0; a--) // ethe main int kita 
       {
           if (data[a] == '1') // ethe main data kita 
               l += s; 
           s*= 2;
       }
       return l; // rt it 
   }


   public static string DecimalToBinary(int data)
   {
       if (data < 0) // ethe main if kita 
           throw new ArgumentException("Unknown character"); // ethe main exeption kita 
       if (data == 0)
           return "0"; // ethe rt it 
       string l = ""; // ethe main string kita 
       while (data > 0) // ethe main while kita 
       {
           l = (data % 2) + l; // ethe main l nu mod kita 
           data = data / 2; 
       }

       return l; // rt it 
   }

   public static bool ConvertFromFile(string inputFile, string outputFile)
   {
       try
       { using StreamReader jww = new(inputFile); // ethe main using stream kita 
           using StreamWriter jss = new(outputFile); // ethe using stream writer kita 
           jss.Close();
           jww.Close();
       }
       catch
       {
           return false; // rt it 
       }
       using StreamReader jr = new(inputFile); 
       string a = jr.ReadLine().Trim(); // ethe main string use kita 
      
       using StreamWriter la = new(outputFile); // fir main ethe streamwriter kita 
       while (a != null)
       {
           bool lv = true; // ethe main bool true kita 
           foreach (char jiv in a)
           {
               if (jiv != '0' && jiv != '1')
               {
                   lv = false; // ethe main vekhya ki lv is equal to false 
                   break;
               }
           }
           try
           {
               string jlp; // ethe main string kita 
               if (lv)
               {
                   jlp = (BinaryToDecimal(a)).ToString(); // ethe main jlp kita 
               }
               else
               {
                   jlp = DecimalToBinary(Int32.Parse(a));
               }


               la.WriteLine(jlp); // ethe main la write line kita 
           }
           catch
           {
               la.WriteLine("Unknown character"); // ethe write line karke main la kita 
           }
           a = jr.ReadLine();
       }
       la.Close(); // ethe main la kita 
       jr.Close(); // ethe main jr kita 


       return true; // ethe main rt it 


   }

 



   public static int CountPath(int x, int y)
   {
       if (x <= 0 || y <= 0) // ethe main if kita 
       { 
           throw new ArgumentException(); // fir main throw exeption kita 
       }
       if (x == 1 || y == 1) // fir main if kita
       {
           return 1; // fir main rt 1 kita 
       }

       return CountPath(x - 1, y) + CountPath(x, y - 1); // ehte main rt coutpath karke 
   }
  
}
