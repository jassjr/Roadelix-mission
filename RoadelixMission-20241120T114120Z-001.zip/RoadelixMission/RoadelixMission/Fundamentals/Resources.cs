namespace RoadelixMission.Fundamentals;

public class Resources
{
    public static bool ResourcesCheck(int dist, int manpower, int wood, int stone, int iron)
    { 
        if (dist < 0) { throw new DistanceException();} // if karke fir execption kita 
        double lo = 10 + (dist / 2.0) + (0.05 * dist) * (0.05 * dist); // fir main double kita 
        int mp = (int)lo; // ethe main int kita 
        if (lo > mp)  mp += 1; // ethe main if kita 
        int k = 50 + (mp * 10) +  dist;  int ms  = dist * 10; int mq= dist * 100; // ethe main int kita 
        return manpower >= mp && wood >= ms && stone >= mq && iron >= k; // rt sari varaible 
    }

}