namespace RoadelixMission.Fundamentals;

public class Distances
{
    public static int EuclideanDistance(int x1, int y1, int x2, int y2)
    { 
        int a = (x1 - x2) * (x1 - x2); // ethe main int kita 
        int b = (y1 - y2) * (y1 - y2); // ethe main int nal multiply kita 
        int w = a + b; // ethe dono main + kite 
        double lv = ApproximateSquareRoot(w);
        int mv = (int)lv; // ethe main int kita fir main int nal lv kita 
        if (lv > mv) mv+= 1; // ethe fir int +1 
        return mv; // ethe main rt it 
    }


    private static double ApproximateSquareRoot(int n)
    { 
        double raman = n; // ethe main double kita 
        double merijaan  = 0.0001; // ehte vi use kita nerjaan 
        while ((raman* raman - n) > merijaan || (raman * raman - n) < -merijaan) raman = (raman + n / raman) / 2.0; // ethe bth kujh likhya 
        return raman; // ethe main rt it 
    }


    public static int ManhattanDistance(int x1, int y1, int x2, int y2)
    { 
        int v = x1 - x2; int m = y1 - y2; // ethe main int kita 
        return (v < 0 ? -v : v) + (m < 0 ? -m : m); // rt it 
    }
    public static int EuclideanDistance2(int x1, int y1, int x2, int y2, double coef)
    { 
        int lv = x1 - x2;  int ma = y1 - y2; // ethe main int kita 
        double pq = coef * (lv * lv + ma * ma);  double prsq = Math.Sqrt(pq); // ethe main double kita 
        return (int)System.Math.Ceiling(prsq); // rt it 
    }

}