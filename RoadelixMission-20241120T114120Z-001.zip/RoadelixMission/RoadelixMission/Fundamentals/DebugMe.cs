namespace RoadelixMission.Fundamentals;

public class DebugMe
{
    public static bool GoodParenthesis(string input)
    {
        int leftParenthesis = 0;
        for (int i = 0; i < input.Length; i++) // ethe main for blc kita 
        {
            if (input[i] == '(')
            {
                leftParenthesis++;
            }
            else if (input[i] == ')')
            {
                if (leftParenthesis == 0)
                {
                    return false; // rt fls 
                }
                leftParenthesis--;
            }
        }
        return leftParenthesis == 0; // rt it 
    }
    public static int Catalan(int n)
    {
        if (n == 0)
        {
            return 1; // ehte main return 1 kita 
        }
        int result = 0; // ethe main result 0 
        for (int i = 0; i < n; i++)
        {
            result += Catalan(i) * Catalan(n - 1 - i);
        }
        return result; // rt it 
    }
    public static (int, int) CalculateSums(int start, int end)
    {
        if (start < 0 || end < 0)
        {
            throw new ArgumentException("Must take positive values");
        }


        int a = 0; // ethe main a kita
        int s = 0; // ehte main s kita 


        for (int i = start; i <= end; i++) // ethe main blc for kita 
        {
            (a, s) = (i % 2 == 0) ? (a + i, s) : (a, s + i);
        }


        return (a, s); // ehte main return kita 
    }
    
    public static string Pyramid(int height)
    {
        return PyramidRec(height, height);
    }


    public static string PyramidRec(int height, int actualLineSize)
    {
        if (actualLineSize <= 0)
        {
            return ""; // ethe return 
        }
        string pyramid = "";  


        int spaces = height - actualLineSize;
        for (int i = 0; i < spaces; i++)
        {
            pyramid += "  ";
        }
        for (int j = 0; j < actualLineSize; j++)
        {
            pyramid += "/_\\";


            if (j != actualLineSize - 1)
            {
                pyramid += "_";
            }
        }
        if (actualLineSize != height)
        { pyramid += '\n';
        } return PyramidRec(height, actualLineSize - 1) + pyramid; // ethe return teh -1 kita kyu ki sahi nahi si 
    }
  
}  
