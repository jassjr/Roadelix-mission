namespace RoadelixMission.Fundamentals;

public class DistanceException : Exception { }
