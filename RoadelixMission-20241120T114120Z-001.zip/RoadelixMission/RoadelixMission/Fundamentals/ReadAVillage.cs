namespace RoadelixMission.Fundamentals;


public class ReadAVillage
{
   public static string GetVillageName(string path)
   {
       try
       {
           using (StreamReader mv = new StreamReader(path)) // ethe main using kita 
           { string ls= mv.ReadLine(); // string kita 
               return string.IsNullOrEmpty(ls) ? "Unknown" : ls; // ethe main return kita 
           } }catch (IOException)
       { return "Unknown"; // rt it exeption kita
       }
   }


   public static (int, int) GetVillageCoords(string path)
   {
       try
       { using (StreamReader lv = new StreamReader(path))
           {
               lv.ReadLine();
               string i2 = lv.ReadLine(); // ethe string kita 
               string i3 = lv.ReadLine(); // ethe vi string kita 
               if (Int32.TryParse(i2, out int a) && Int32.TryParse(i3, out int b)) // ethe main if karna 
                   return (a, b);// rt a and b 
               
           } }catch (IOException) {} // ethe main catch kita 
       return (-1, -1); // rt -1 kita 
   }
   
   public static (string, string, string, string) GetVillageResources(string path)
   {
       try
       {
           using (StreamReader jr = new StreamReader(path))
           {
               string la ; // ethe main string kita 
               int alv = 0;// ethe main int kita 
               string m1 = "0", 
                      m2 = "0",
                      m3 = "0", 
                      m4 = "0";
               while ((la = jr.ReadLine()) != null) // ethe main while kita 
               { alv++; 
                   if (alv == 4) m1 = la; else if (alv== 5) m2 = la; else if (alv == 6) m3 = la; else if (alv == 7) m4 = la;
                   
                   if (alv >= 7) break; // ethe main if kita 
               }
               return (m1, m2, m3, m4); // rt it m1 m2 m2 m3 m4 
           }
       }
       catch (IOException)
       {
           return ("0", "0", "0", "0"); // rt it 
       }
   }
   
   public static int ConvertBase7ToDecimal(string data)
   {
       int j = 0;


       for (int q = 0; q< data.Length; q++)
       {
           if (data[q] < '0'
               || data[q] > '6') // ethe main if kkita teh bool 
               throw new ArgumentException("Unknown character"); // ethe main throw argument kit a
           j = j * 7 + (data[q] - '0'); // ethe main j kita 

       } return j;// rt it j
    }
}





