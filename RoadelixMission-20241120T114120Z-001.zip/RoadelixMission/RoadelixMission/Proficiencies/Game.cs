namespace RoadelixMission.Proficiencies;

public class Game
{
    public static void PrintGameState(int gold, int materials, int guards, int strength, int turn, int progress) { }

    public static bool ExecuteTurn(ref int gold, ref int materials, ref int guards, ref int strength, ref int progress, int turn) { }

    public static void ExecuteGame(string input, string output) { }

}