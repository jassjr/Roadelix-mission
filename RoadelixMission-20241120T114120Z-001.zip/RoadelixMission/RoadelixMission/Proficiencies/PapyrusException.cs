namespace RoadelixMission.Proficiencies;

public class PapyrusException : Exception
    {
        public PapyrusException() : base() { }
        public PapyrusException(string message) : base(message) { }
    }

