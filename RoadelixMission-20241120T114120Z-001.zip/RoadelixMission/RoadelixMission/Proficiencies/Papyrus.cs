namespace RoadelixMission.Proficiencies;

public class Papyrus
{
    public static string GetParameter(string line)
    {
        int p = line.IndexOf(':'); // ethe int p kita 
        if (p == -1) throw new PapyrusException("Did not find separator"); // ethe etp thrw kiti 
        if (p == 0) throw new PapyrusException("Did not find parameter"); // ethe etp thrw kiti
        return line.Substring(0, p); // rt it 
    }


    public static string GetData(string line)
    {
        if (string.IsNullOrWhiteSpace(line) || !line.Contains(":"))  throw new PapyrusException("");  // thrw exep
        var a = line.Split(':');
        if (a.Length < 2 || string.IsNullOrEmpty(a[1])) throw new PapyrusException(""); // trw execp
        string mv = a[1]; // string mv kita main 
        if (!int.TryParse(mv, out int value) || value <= 0) throw new PapyrusException("");  // trhw exept 
        return mv; // rt it 
    }
    public static void ReadPapyrus(ref int gold, ref int materials, ref int guards, ref int strength, string input) { }

}
