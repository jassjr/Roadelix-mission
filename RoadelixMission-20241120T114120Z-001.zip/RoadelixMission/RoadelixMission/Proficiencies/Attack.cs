namespace RoadelixMission.Proficiencies;

public class Attack
{
    public static int RegimentSize(int n)
    {
        if (n < 0) throw new ArgumentException(""); // ethe main trw arg karna 

        return n * (n + 1) / 2; // ethe main rt karna 

    }
        public static bool GuardAttack(ref int guards, int strength, ref int romans, ref int gold)
        {
            int lov = guards * strength; int mt = lov > romans ? romans : lov; // ethe if kita teh fir strenght kita 
            romans -= mt; gold += mt* 2; // ethe mt 2 nal multiply kita 

            if (romans == 0) return true; // ethe if kita 
            return RomanAttack(ref guards, strength, ref romans, ref gold); // rt saree ref 
        }

        public static bool RomanAttack(ref int guards, int strength, ref int romans, ref int gold)
        {
            int tov = romans / strength; int st = tov > guards ? guards : tov; // ethe int kita 
            guards -= st; gold -= st; // ethe st kita 

            if (guards == 0) return false; // ethe rt kita fls 

            return GuardAttack(ref guards, strength, ref romans, ref gold); // rt sare ref kite 
        }
    }
